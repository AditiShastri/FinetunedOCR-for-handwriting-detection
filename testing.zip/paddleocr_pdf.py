import os
from pdf2image import convert_from_path
from paddleocr import PaddleOCR

# Function to initialize PaddleOCR
def initialize_ocr():
    model_path = "C:\\Users\\aditi\\Desktop\\paddle\\best_model"  # Update with your actual model directory path
    dict_path = "C:\\Users\\aditi\\Desktop\\paddle\\en_dict.txt"  # Update with your actual dictionary file path
    return PaddleOCR(
        rec_model_dir=model_path,
        use_angle_cls=True,
        lang='en',
        e2e_char_dict_path=dict_path
    )

# Function to process PDF file and extract text
def process_pdf(pdf_path, output_txt_path):
    try:
        # Convert PDF pages to images
        images = convert_from_path(pdf_path)
        
        # Initialize OCR
        ocr = initialize_ocr()

        # List to store text from each page
        all_text = []
        
        # Process each page
        for page_num, image in enumerate(images, start=1):
            print(f"Processing page {page_num}...")

            # Perform OCR on the image
            result = ocr.ocr(image, cls=True)

            # Extract text from OCR result
            page_text = "\n".join([line[1][0] for line in result[0]])
            all_text.append(f"--- Page {page_num} ---\n{page_text}\n\n")
        
        # Save extracted text to file
        with open(output_txt_path, "w", encoding="utf-8") as txt_file:
            txt_file.write("".join(all_text))
        print(f"Text successfully extracted and saved to {output_txt_path}")

    except Exception as e:
        print(f"Error processing PDF: {e}")

pdf_path="C:\\Users\\aditi\\Desktop\\paddle\\Unit_5__Inferential_Statistic[1].pdf"
output_txt_path = "C:\\Users\\aditi\\Desktop\\paddle\\Unit_5__Inferential_Statistic[1].txt"  # Path where you want to save the extracted text

process_pdf(pdf_path, output_txt_path)
